from config import *
from models import Telefone, Usuario, Operadora


@app.route("/")
def index():
    return "<a href='/listar_telefones'>teste de back-end</a>"


@app.route("/listar_telefones")
def listar_telefones():
    telefones = db.session.query(Telefone).all()
    json_telefones = [x.json() for x in telefones]
    resultado = jsonify(json_telefones)
    resultado.headers.add("Access-Control-Allow-Origin", "*")
    return resultado


@app.route("/incluir_telefones", methods=["POST"])
def incluir_telefones():
    resultado = jsonify({"status": "ok",
                         "details": "none"})
    data_post = request.get_json()
    try:
        new = Telefone(**data_post)
        db.session.add(new)
        db.session.commit()
    except Exception as e:
        resultado = jsonify({"status": "error",
                          "details": str(e)})
    resultado.headers.add("Access-Control-Allow-Origin", "*")
    return resultado


@app.route("/excluir_telefones/<int:num_id>", methods=["DELETE"])
def excluir_telefones(num_id):
    resultado = jsonify({"status": "ok", "details": "none"})
    try:
        Telefone.query.filter(Telefone.id == num_id).delete()
        db.session.commit()
    except Exception as e:
        resultado = jsonify({"status": "error", "details": str(e)})
    resultado.headers.add("Access-Control-Allow-Origin", "*")
    return resultado


@app.route("/listar_usuarios")
def listar_usuarios():
    usuarios = db.session.query(Usuario).all()
    json_usuarios = [x.json() for x in usuarios]
    resultado = jsonify(json_usuarios)
    resultado.headers.add("Access-Control-Allow-Origin", "*")
    return resultado


@app.route("/listar_operadoras")
def listar_operadoras():
    operadoras = db.session.query(Operadora).all()
    json_operadoras = [x.json() for x in operadoras]
    resultado = jsonify(json_operadoras)
    resultado.headers.add("Access-Control-Allow-Origin", "*")
    return resultado