from config import *


class Telefone(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ddd = db.Column(db.String(254))
    numero = db.Column(db.String(254))


    def __str__(self):
        return f"{self.id}) ({self.ddd}) {self.numero}"


    def json(self):
        return {
            "id": self.id,
            "ddd": self.ddd,
            "numero": self.numero
        }


class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cpf = db.Column(db.String(14))
    nome = db.Column(db.String(254))
    email = db.Column(db.String(254))

    telefone_id = db.Column(db.Integer, db.ForeignKey(Telefone.id), nullable=False)
    telefone = db.relationship("Telefone")


    def __str__(self):
        return f"{self.id} {self.cpf}, {self.nome}, {self.email}, {self.telefone.json()}"


    def json(self):
        return {
            "id": self.id,
            "cpf": self.cpf,
            "nome": self.nome,
            "email": self.email,
            "telefone": self.telefone.json(),
        }


class Operadora(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cnpj = db.Column(db.String(10))
    nome = db.Column(db.String(254))
    endereco = db.Column(db.String(254))

    telefone_id = db.Column(db.Integer, db.ForeignKey(Telefone.id), nullable=False)
    telefone = db.relationship("Telefone")

    usuario_id = db.Column(db.Integer, db.ForeignKey(Usuario.id), nullable=False)
    usuario = db.relationship("Usuario")


    def __str__(self):
        return f"{self.id}) {self.cnpj}, {self.nome}, {self.endereco}, " +\
               f"{self.telefone.json()}, {self.usuario.json()}"


    def json(self):
        return {
            "id": self.id,
            "cnpj": self.cnpj,
            "nome": self.nome,
            "endereco": self.endereco,
            "telefone_id": self.telefone_id,
            "telefone": self.telefone.json(),
            "usuario_id": self.usuario_id,
            "usuario": self.usuario.json(),
        }


if __name__ == "__main__":

    if os.path.exists(db_path):
        os.remove(db_path)
    db.create_all()

    t1 = Telefone(ddd="57", numero="9999-9999")
    db.session.add(t1)

    u1 = Usuario(cpf="111.111.111-11", nome="Maico Jaco", email="McJaco@gmail.com", telefone=t1)
    db.session.add(u1)

    o1 = Operadora(cnpj="58.11-5-00", nome="Tchau", endereco="R. Vazia; Vinewood", telefone=t1, usuario=u1)
    db.session.add(o1)

    db.session.commit()

    print(t1)
    print(t1.json())
    print('\n')
    print(u1)
    print(u1.json())
    print('\n')
    print(o1)
    print(o1.json())