$( document ).ready(function() {
  mostrarConteudo("inicial");

  $("#listar_telefones").click(function () {
    $.ajax({
      url: "http://localhost:5000/listar_telefones",
      method: "GET",
      dataType: "json",
      success: listarTelefones,
      error: function () {
        alert("back-end não conectado!");
      }
    });

    function listarTelefones(telefones) {
      $("#tabela_telefones").empty();

      mostrarConteudo("telefones");

      for (var i in telefones) {
        line = "<tr id='linha_" + telefones[i].id + "'>" +
          "<td>" + telefones[i].id + "</td>" +
          "<td>" + telefones[i].ddd + "</td>" +
          "<td>" + telefones[i].numero + "</td>" +
	        '<td><a href=# id="excluir_' + telefones[i].id + '" ' +
            'class="excluir_num"><img src="imagens/excluir.png" ' +
            'alt="excluir" style="width: 25px; height: 25px" title="excluir"></a>' +
          '</td>' +
          "</tr>";
        $("#tabela_telefones").append(line);
      };
    };
  });

  $("#listar_usuarios").click(function () {
    $.ajax({
      url: "http://localhost:5000/listar_usuarios",
      method: "GET",
      dataType: "json",
      success: listarUsuarios,
      error: function () {
        alert("back-end não conectado!");
      }
    });

    function listarUsuarios(usuarios) {
      $("#lista_usuarios tr>td").remove();

      mostrarConteudo("usuarios");

      for (var i in usuarios) {
        line = "<tr id='linha_" + usuarios[i].id + "'>" +
          "<td>" + usuarios[i].cpf + "</td>" +
          "<td>" + usuarios[i].nome + "</td>" +
          "<td>" + usuarios[i].email + "</td>" +
          "<td>" + usuarios[i].telefone.ddd + "</td>" +
          "<td>" + usuarios[i].telefone.numero + "</td>" +
          "</tr>";
        $("#tabela_usuarios").append(line);
      };
    };
  });

  $("#listar_operadoras").click(function () {
    $.ajax({
      url: "http://localhost:5000/listar_operadoras",
      method: "GET",
      dataType: "json",
      success: listarOperadoras,
      error: function () {
        alert("back-end não conectado!");
      }
    });

    function listarOperadoras(operadoras) {
      $("#lista_operadoras tr>td").remove();

      mostrarConteudo("operadoras");

      for (var i in operadoras) {
        line = "<tr id='linha_" + operadoras[i].id + "'>" +
          "<td>" + operadoras[i].cnpj + "</td>" +
          "<td>" + operadoras[i].nome + "</td>" +
          "<td>" + operadoras[i].endereco + "</td>" +
          "<td>" + operadoras[i].usuario.cpf + "</td>" +
          "<td>" + operadoras[i].usuario.nome + "</td>" +
          "<td>" + operadoras[i].usuario.email + "</td>" +
          "<td>" + operadoras[i].telefone.ddd + "</td>" +
          "<td>" + operadoras[i].telefone.numero + "</td>" +
          "</tr>";
        $("#tabela_operadoras").append(line);
      };
    };
  });

  function mostrarConteudo(conteudo){
    $("#telefones").addClass('d-none');
    $("#usuarios").addClass('d-none');
    $("#operadoras").addClass('d-none');
    $("#inicial").addClass('d-none');
    $(`#${conteudo}`).removeClass('d-none');
  }

  $("#incluir_num").click(function () {
    input_dd = $("#input_dd").val();
    input_numero = $("#input_numero").val();

    var data_post = JSON.stringify({
      ddd: input_dd,
      numero: input_numero,
    });


    $.ajax({
      url: "http://localhost:5000/incluir_telefones",
      type: "POST",
      contentType: "application/json",
      dataType: "json",
      data: data_post,
      success: incluirNum,
      error: incluirNumErro
    });

    function incluirNum(resultado) {
      if (resultado.status == "ok") {
        alert("telefone incluído com sucesso");
        $("#input_dd").val("");
        $("#input_numero").val("");
      } else {
        alert("erro ao incluir telefone");
      }
    };

    function incluirNumErro(result) {
      alert("erro no back-end!");
    };
  });

  $(document).on("click", ".excluir_num", function() {
    component_id = $(this).attr("id");
    identifier_str = "excluir_";
    var id_num = component_id.substring(identifier_str.length);
    $.ajax({
      url: "http://localhost:5000/excluir_telefones/" + id_num,
      type: "DELETE",
      dataType: "json",
      success: numExcluido,
      error: erroExcluir
    });

    function numExcluido(resultado) {
      if (resultado.status == "ok") {
        $("#linha_" + id_num).fadeOut(1000, function() {
          alert("Exclusão concluída");
        });
      } else {
        alert(resultado.status + ": " + resultado.details);
      };
    };

    function erroExcluir(resultado) {
      alert("erro no back-end!");
    };
  });
});



