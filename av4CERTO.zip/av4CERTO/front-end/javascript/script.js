$( document ).ready(function() {
  $("#mensagem_inicial").removeClass("invisible");
  $("#listar_telefones").click(function () {
    $.ajax({
      url: "http://localhost:5000/listar_telefones",
      method: "GET",
      dataType: "json",
      success: listarNums,
      error: function () {
        alert("back-end não conectado!");
      }
    });
    function listarNums(nums) {
      $("#lista_nums tr>td").remove();
      for (var i in nums) {
        line = "<tr id='linha_" + nums[i].id + "'>" +
          "<td>" + nums[i].id + "</td>" +
          "<td>" + nums[i].nome + "</td>" +
          "<td>" + nums[i].dd + "</td>" +
          "<td>" + nums[i].numero + "</td>" +
	  '<td><a href=# id="excluir_' + nums[i].id + '" ' +
          'class="excluir_num"><img src="imagens/excluir.png" ' +
          'alt="excluir" title="excluir"></a>' +
          '</td>' +
          "</tr>";
        $("#tabela_nums").append(line);
      };
      $("#mensagem_inicial").addClass("invisible");
      $("#lista_nums").removeClass("invisible");
    };
  });
  $("#incluir_num").click(function () {
    input_nome = $("#input_nome").val();
    input_dd = $("#input_dd").val();
    input_numero = $("#input_numero").val();
    data_post = JSON.stringify({
      nome: input_nome,
      dd: input_dd,
      numero: input_numero,
    });
    $.ajax({
      url: "http://localhost:5000/incluir_telefones",
      type: "POST",
      contentType: "application/json",
      dataType: "json",
      data: data_post,
      success: incluirNum,
      error: incluirNumErro
    });
    function incluirNum(resultado) {
      if (resultado.status == "ok") {
        alert("telefone incluído com sucesso");
        $("#input_nome").val("");
        $("#input_dd").val("");
        $("#input_numero").val("");
      } else {
        alert("erro ao incluir telefone");
      }
    };
    function incluirNumErro(result) {
      alert("erro no back-end!");
    };
  });
  $( document ).on("click", ".excluir_num", function() {
    component_id = $(this).attr("id");
    identifier_str = "excluir_";
    var id_num = component_id.substring(identifier_str.length);
    $.ajax({
      url: "http://localhost:5000/excluir_telefones/" + id_num,
      type: "DELETE",
      dataType: "json",
      success: numExcluido,
      error: erroExcluir
    });
    function numExcluido(resultado) {
      if (resultado.status == "ok") {
        $("#linha_" + id_num).fadeOut(1000, function() {
          alert("Exclusão concluída");
        });
      } else {
        alert(resultado.status + ": " + resultado.details);
      };
    };
    function erroExcluir(resultado) {
      alert("erro no back-end!");
    };
  });
});



