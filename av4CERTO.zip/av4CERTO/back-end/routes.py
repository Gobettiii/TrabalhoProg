from config import *
from models import Telefone


@app.route("/")
def index():
    return "<a href='/listar_telefones'>teste de back-end</a>"


@app.route("/listar_telefones")
def listar_telefones():
    nums = db.session.query(Telefone).all()
    json_nums = [x.json() for x in nums]
    resultado = jsonify(json_nums)
    resultado.headers.add("Access-Control-Allow-Origin", "*")
    return resultado


@app.route("/incluir_telefones", methods=["POST"])
def incluir_telefones():
    resultado = jsonify({"status": "ok",
                      "details": "none"})
    data_post = request.get_json()
    try:
        new = Telefone(**data_post)
        db.session.add(new)
        db.session.commit()
    except Exception as e:
        resultado = jsonify({"status": "error",
                          "details": str(e)})
    resultado.headers.add("Access-Control-Allow-Origin", "*")
    return resultado


@app.route("/excluir_telefones/<int:num_id>", methods=["DELETE"])
def excluir_telefones(num_id):
    resultado = jsonify({"status": "ok", "details": "none"})
    try:
        Telefone.query.filter(Telefone.id == num_id).delete()
        db.session.commit()
    except Exception as e:
        resultado = jsonify({"status": "error", "details": str(e)})
    resultado.headers.add("Access-Control-Allow-Origin", "*")
    return resultado

